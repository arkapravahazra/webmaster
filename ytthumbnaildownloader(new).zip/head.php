<link rel="stylesheet" href="/css/style.css">
<link async rel="stylesheet" href="/ytg.css">
<link rel="icon" href="/img/logo.png" type="image/x-icon" />