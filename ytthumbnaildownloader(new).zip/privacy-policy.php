<!DOCTYPE html>
<html lang="en-us">
		<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<meta name="description" content="">
		<title>Privacy Policy</title>
			<?php include("head.php"); ?>
	</head>
<script>
	function copyNow(element) {
  var copyText = document.getElementById(element);
  copyText.select();
  document.execCommand("copy");
}
</script>
<style>
body {
	font-family: 'Fira Sans',sans-serif;
}
</style>
		<body>
<?php include("analytics.php"); ?>

<?php include("header.php"); ?>

<main style='margin: 0 auto;'>

<div class='bodyContainer'>
    <!-- CONTENT COMES HERE -->
</div>


<script type="text/javascript" src="/ytg.js">
</script>
</main>

<?php include("footer.php"); ?>


    </body>
        

</html>