    <nav class="nav">
			<div class="nav-container" style="width: 100%;max-width:100%;padding-left:20px;">
				<a href="/">
					<h1 class="nav-title" style='font-size: 24px;'>iYoutubeThumbnailDownloader.com</h1>
				</a>
				<ul style="padding-right:20px;">
		<li ><a href="/about-us.php">About Us</a></li>
		<li ><a href="/contact-us.php">Contact Us</a></li>
		<li ><a href="/privacy-policy.php">Prvacy Policy</a></li>
</ul>
			</div>
		</nav>